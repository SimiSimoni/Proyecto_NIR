import Pkg
using Pkg
Pkg.Registry.update()
Pkg.update()
Pkg.resolve()

Pkg.add("MAT")

using LinearAlgebra
using Statistics
using Printf
using MAT
using DataFrames
using Plots



function cargar_datos_mat(path)
    vars = matread(path)
    espectros = Float64.(vars["m5spec"]["data"])
    props = Float64.(vars["propvals"]["data"])
    wl = collect(1100:2:2498)  # 700 puntos, 2 nm

    df = DataFrame(espectros, string.(wl))
    df.humedad  = props[:, 1]
    df.aceite   = props[:, 2]
    df.proteina = props[:, 3]
    df.almidon  = props[:, 4]
    return df, wl
end

"SNV por fila"
function snv(X::AbstractMatrix)
    Xo = similar(X, Float64)
    for i in axes(X, 1)
        fila = @view X[i, :]
        Xo[i, :] = (fila .- mean(fila)) ./ std(fila; corrected=false)
    end
    return Xo
end

"Savitzky-Golay funciona similar a scipy.signal.savgol_filter, pero con soporte para ventana par."

function savgol_fila(x::AbstractVector, w::Int, p::Int, d::Int)
    n = length(x)
    half = w ÷ 2
    pos = iseven(w) ? (w - 1) / 2 : w ÷ 2

    # Pesos de convolución
    r = collect(-half:(w - 1 - half))      # offsets relativos de las muestras
    xr = r .- half .+ pos                  # coordenada polinómica
    A = [xi^k for xi in xr, k in 0:p]
    c = factorial(d) .* pinv(A)[d + 1, :]

    y = zeros(Float64, n)
    for i in (half + 1):(n - half)         # índices 1-based; interior
        s = 0.0
        for (m, rm) in enumerate(r)
            idx = i + rm
            (1 <= idx <= n) && (s += c[m] * x[idx])
        end
        y[i] = s
    end

    # Bordes
    function ajustar_borde!(ini, fin, destino)
        tt = collect(0:(w - 1))
        V = [t^k for t in tt, k in 0:p]
        coef = V \ x[ini:fin]
        for i in destino
            t = i - ini
            y[i] = sum(coef[k + 1] * factorial(k) / factorial(k - d) * t^(k - d)
                       for k in d:p)
        end
    end
    ajustar_borde!(1, w, 1:half)
    ajustar_borde!(n - w + 1, n, (n - half + 1):n)
    return y
end

function savgol(X::AbstractMatrix; window_length, polyorder, deriv)
    Xo = similar(X, Float64)
    for i in axes(X, 1)
        Xo[i, :] = savgol_fila(X[i, :], window_length, polyorder, deriv)
    end
    return Xo
end


struct PLSModelo
    coef::Vector{Float64}
    intercepto::Float64
end

function pls_fit(X::AbstractMatrix, y::AbstractVector, ncomp::Int)
    xm = vec(mean(X; dims=1))
    xs = vec(std(X; dims=1))
    xs[xs .== 0] .= 1.0
    ym, ys = mean(y), std(y)

    Xs = (X .- xm') ./ xs'
    yc = (y .- ym) ./ ys

    n, p = size(X)
    W = zeros(p, ncomp)
    P = zeros(p, ncomp)
    q = zeros(ncomp)

    for a in 1:ncomp
        w = Xs' * yc
        w ./= norm(w)
        t = Xs * w
        tt = dot(t, t)
        P[:, a] = Xs' * t / tt
        q[a] = dot(yc, t) / tt
        W[:, a] = w
        Xs .-= t * P[:, a]'
        yc .-= q[a] .* t
    end

    B_esc = W * ((P' * W) \ q)
    coef = B_esc .* ys ./ xs
    intercepto = ym - dot(xm, coef)
    return PLSModelo(coef, intercepto)
end

pls_predict(m::PLSModelo, X::AbstractMatrix) = X * m.coef .+ m.intercepto


preprocesar(X) = savgol(snv(X); window_length=10, polyorder=2, deriv=1)

"Equivalente a cross_val_predict(cv=10) con KFold sin barajar."

function cross_val_predict_pls(X, y, ncomp; k=10)
    n = length(y)
    base, extra = divrem(n, k)
    tamanos = [base + (i <= extra ? 1 : 0) for i in 1:k]
    y_pred = zeros(n)
    inicio = 1
    for tam in tamanos
        test = inicio:(inicio + tam - 1)
        train = setdiff(1:n, test)
        Xtr = preprocesar(X[train, :])
        Xte = preprocesar(X[test, :])
        modelo = pls_fit(Xtr, y[train], ncomp)
        y_pred[test] = pls_predict(modelo, Xte)
        inicio += tam
    end
    return y_pred
end

rmse(y, yp) = sqrt(mean((y .- yp) .^ 2))
r2(y, yp) = 1 - sum((y .- yp) .^ 2) / sum((y .- mean(y)) .^ 2)


function ejecutar_analisis_espectral()
    # Definir rutas
    data_path = joinpath(@__DIR__, "data", "corn.mat")
    df_complete, _ = cargar_datos_mat(data_path)

    cols_quimicas = ["humedad", "aceite", "proteina", "almidon"]
    X_df = select(df_complete, Not(cols_quimicas))

    # Recorte espectral
    wavelengths = [parse(Float64, c) for c in names(X_df)]
    mask_trim = (wavelengths .>= 1150) .& (wavelengths .<= 2450)
    X_trimmed = Matrix{Float64}(X_df[:, mask_trim])
    wavelengths_trimmed = wavelengths[mask_trim]

    ncomp = 5
    colores = [:teal, :crimson, :darkorange, :purple]
    resultados = DataFrame()
    plots_pred = Plots.Plot[]
    plots_coef = Plots.Plot[]

    println("=== EJECUTANDO MODELADO MULTIVARIABLE PLSR (5 LVs) ===")

    for (i, prop) in enumerate(cols_quimicas)
        y = Float64.(df_complete[!, prop])

        # Cross Val n=10
        y_pred_cv = cross_val_predict_pls(X_trimmed, y, ncomp; k=10)
        rmsecv = rmse(y, y_pred_cv)
        r2_cv = r2(y, y_pred_cv)
        rpd = std(y; corrected=false) / rmsecv   # np.std (ddof=0)

        # Calibración y coeficientes
        modelo = pls_fit(preprocesar(X_trimmed), y, ncomp)
        y_pred_cal = pls_predict(modelo, preprocesar(X_trimmed))
        rmsec = rmse(y, y_pred_cal)

        coefs = modelo.coef
        top_idx = sortperm(abs.(coefs); rev=true)[1:3]
        top_wv = wavelengths_trimmed[top_idx]
        top_wv_str = join(["$(Int(floor(wv)))nm" for wv in top_wv], ". ")

        push!(resultados, (
            Propiedad = uppercasefirst(prop),
            var"Std(Y)" = round(std(y; corrected=false), digits=3),
            RMSEC = round(rmsec, digits=4),
            RMSECV = round(rmsecv, digits=4),
            var"Ratio CV/Cal" = round(rmsecv / rmsec, digits=2),
            var"R²_CV" = round(r2_cv, digits=3),
            RPD = round(rpd, digits=2),
            var"Picos Max |β|" = top_wv_str,
        ))

        # Referencia vs Predicho
        titulo = @sprintf("%s | RMSECV: %.3f | R²: %.3f | RPD: %.2f",
                          uppercasefirst(prop), rmsecv, r2_cv, rpd)
        p1 = scatter(y, y_pred_cv; color=colores[i], alpha=0.7,
                     markerstrokecolor=:black, label="",
                     title=titulo, titlefontsize=8,
                     xlabel="Valor Real (%)", ylabel="Predicción CV (%)",
                     grid=true, gridalpha=0.3)
        plot!(p1, [minimum(y), maximum(y)], [minimum(y), maximum(y)];
              color=:red, linestyle=:dash, lw=1.5, label="")
        push!(plots_pred, p1)

        # Filtros espectrales (pesos beta)
        p2 = plot(wavelengths_trimmed, coefs; color=colores[i], lw=1.5,
                  label="Filtro β: $(uppercasefirst(prop))",
                  legend=:topright, ylabel="Peso β",
                  grid=true, gridalpha=0.3,
                  xlabel=(i == length(cols_quimicas) ? "Longitud de Onda (nm)" : ""))
        hline!(p2, [0]; color=:black, linestyle=:dash, alpha=0.5, label="")
        push!(plots_coef, p2)
    end

    fig_pred = plot(plots_pred...; layout=(2, 2), size=(1100, 900),
                    plot_title="Ajuste de Calibración Cruzada por Propiedad")
    fig_coef = plot(plots_coef...; layout=(4, 1), size=(1100, 1000),
                    plot_title="Filtros Espectrales (Coeficientes PLS) por Propiedad Química")

    # Impresión de tabla consolidada
    println()
    show(resultados; allrows=true, allcols=true, show_row_number=false)
    println()

    display(fig_pred)
    display(fig_coef)
    return resultados
end

if abspath(PROGRAM_FILE) == @__FILE__
    ejecutar_analisis_espectral()
end