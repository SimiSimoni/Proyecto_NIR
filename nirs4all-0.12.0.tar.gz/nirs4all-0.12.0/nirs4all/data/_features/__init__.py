"""Feature management components and utilities."""

# ruff: noqa: I001 - import order is load-order sensitive (circular import prevention)
from .feature_constants import (
    FeatureLayout,
    HeaderUnit,
    LayoutType,
    DEFAULT_PROCESSING,
    normalize_layout,
    normalize_header_unit,
)
from .array_storage import ArrayStorage, SharedBlocks
from .processing_manager import ProcessingManager
from .header_manager import HeaderManager
from .layout_transformer import LayoutTransformer
from .update_strategy import UpdateStrategy, ReplacementOperation, AdditionOperation
from .augmentation_handler import AugmentationHandler
from .feature_source import FeatureSource

__all__ = [
    # Constants and enums
    "FeatureLayout",
    "HeaderUnit",
    "LayoutType",
    "DEFAULT_PROCESSING",
    "normalize_layout",
    "normalize_header_unit",
    # Main class
    "FeatureSource",
    # Internal components
    "ArrayStorage",
    "SharedBlocks",
    "ProcessingManager",
    "HeaderManager",
    "LayoutTransformer",
    "UpdateStrategy",
    "ReplacementOperation",
    "AdditionOperation",
    "AugmentationHandler",
]
